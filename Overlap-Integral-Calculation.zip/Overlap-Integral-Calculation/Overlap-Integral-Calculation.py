import pandas as pd
import numpy as np
from scipy.interpolate import interp1d
from scipy.integrate import simps

# Load the CSV file
df = pd.read_csv("fret.csv")

# Extract columns
abs_wl = df["abwavelength"].values.astype(float)
abs_intensity = df["abintensity"].values.astype(float)
em_wl = df["emwavelength"].values.astype(float)
em_intensity = df["emintensity"].values.astype(float)

# Define common wavelength range
common_wl = np.linspace(max(min(abs_wl), min(em_wl)),
                        min(max(abs_wl), max(em_wl)), 500)

# Interpolate both spectra
interp_abs = interp1d(abs_wl, abs_intensity, bounds_error=False, fill_value=0.0)
interp_em = interp1d(em_wl, em_intensity, bounds_error=False, fill_value=0.0)

abs_interp = interp_abs(common_wl)
em_interp = interp_em(common_wl)

# Normalize donor emission spectrum
em_interp_norm = em_interp / simps(em_interp, common_wl)

# Calculate spectral overlap integral J(λ)
J = simps(em_interp_norm * abs_interp * (common_wl ** 4), common_wl)

# Define Förster radius constants
QY = 0.27     # Quantum yield
n = 1.33     # Refractive index
k2 = 2/3     # Orientation factor
c = 0.211    # Numerical coefficient

# Calculate Förster distance R0
R0 = c * ((k2 * QY * J) / (n ** 4)) ** (1/6)

# Output results
print(f"Spectral Overlap Integral J(λ): {J:.2e} M⁻¹cm⁻¹nm⁴")
print(f"Förster Radius R₀: {R0:.2f} nm")

# J shows the strength of the energy transfer
# That means at a distance of R0 in nanometers, energy transfer efficiency between donor and acceptor would be 50%